// Select elements using jQuery
const int1 = $("#int1");
const int2 = $("#int2");
const op = $("#op");
const calu = $("#calu");

// setInterval is TimerHandler to make somethings in time
setInterval(() => {
    // Alert "Pls, use me..."
    alert("Please, use me...");
}, 30000);

// Event listener for form submission using jQuery
calu.submit((event) => {
    event.preventDefault();
    const value1 = int1.val();
    const value2 = int2.val();
    const opar = op.val();

    // Check if the values are less than 0
    if (value1 < 0 || value2 < 0) {
        alert("Error :(");
        console.log("Error :( Value must be >= 0");
        return;
    }
    // Check for division by 0
    if ((opar == "/" || opar == "%") && (value1 == 0 || value2 == 0)) {
        alert("It's over 9000!");
        console.log("It's over 9000!");
        return;
    }

    // Evaluate the expression and display the result
    const result = eval(`${value1} ${opar} ${value2}`);
    alert("Result : " + result);
    console.log("Result : " + result);
});