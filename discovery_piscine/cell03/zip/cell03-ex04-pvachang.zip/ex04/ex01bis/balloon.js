$(document).ready(function () {
    let size = 200;
    let click = 0;
    let colors = ['red', 'green', 'blue'];

    const setSize = (size) => {
        const newSize = Math.min(Math.max(size, 200), 420);
        $("#balloon").css({
            width: `${newSize}px`,
            height: `${newSize}px`
        });
    };

    $("#balloon").click(function () {
        if (size < 420) {
            size += 10;
            setSize(size);
        } else {
            size = 200;
            setSize(size);
        }
        click = (click + 1) % 3;
        console.log("click :" + colors[click]);
        $("#balloon").css("background-color", colors[click]);
    });

    $("#balloon").mouseover(function () {
        if (size - 5 >= 200) {
            size -= 5;
            setSize(size);
            if (click - 1 < 0) {
                console.log("over: " + click);
                $("#balloon").css("background-color", colors[2]);
            } else {
                $("#balloon").css("background-color", colors[(click - 1) % 3]);
            }
        } else {
            return;
        }
    });

    $("#balloon").mouseleave(function () {
        console.log("3 : " + click);
        $("#balloon").css("background-color", colors[click]);
    });
});